import { useEffect, useMemo, useState } from 'react'
import {
  ChevronDown,
  CheckCircle2,
  Circle,
  Star,
  ExternalLink,
  Search,
  Code2,
  Wifi,
  WifiOff,
} from 'lucide-react'
import {
  fetchDsaCompanies,
  fetchDsaQuestions,
  fetchDsaProgress,
  toggleDsaSolved,
  toggleDsaRevision,
} from '../services/api'

const DIFFICULTY_STYLES = {
  EASY: 'bg-teal-50 text-teal-700 border-teal-200',
  MEDIUM: 'bg-amber-50 text-amber-700 border-amber-200',
  HARD: 'bg-rose-50 text-rose-700 border-rose-200',
}

const DIFFICULTY_FILTERS = ['All', 'EASY', 'MEDIUM', 'HARD']

const PAGE_SIZE = 100

function ProgressPill({ solved, total }) {
  const pct = total > 0 ? Math.round((solved / total) * 100) : 0
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-100">
        <div className="h-full rounded-full bg-teal-500" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-medium text-slate-500">{pct}%</span>
    </div>
  )
}

function CompanySection({
  companyStat,
  isOpen,
  onToggle,
  questions,
  isLoading,
  solvedSet,
  revisionSet,
  onToggleSolved,
  onToggleRevision,
}) {
  const [difficulty, setDifficulty] = useState('All')
  const [search, setSearch] = useState('')
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)

  const filtered = useMemo(() => {
    let list = questions
    if (difficulty !== 'All') list = list.filter((q) => q.difficulty === difficulty)
    if (search.trim()) {
      const s = search.toLowerCase()
      list = list.filter(
        (q) => q.title.toLowerCase().includes(s) || q.topics.some((t) => t.toLowerCase().includes(s))
      )
    }
    return list
  }, [questions, difficulty, search])

  const solvedInCompany = questions.filter((q) => solvedSet.has(q._id)).length

  return (
    <div className="rounded-xl border border-slate-200 bg-white shadow-card">
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-900 text-[11px] font-semibold text-white">
            {companyStat.company.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900">{companyStat.company}</p>
            <p className="text-xs text-slate-500">
              {companyStat.total} questions · {companyStat.easy} Easy · {companyStat.medium} Medium ·{' '}
              {companyStat.hard} Hard
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <ProgressPill solved={solvedInCompany} total={companyStat.total} />
          <ChevronDown
            size={18}
            className={`text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="border-t border-slate-100 px-5 pb-5 pt-4">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-1.5">
              {DIFFICULTY_FILTERS.map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => {
                    setDifficulty(d)
                    setVisibleCount(PAGE_SIZE)
                  }}
                  className={[
                    'rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors',
                    difficulty === d
                      ? 'border-slate-900 bg-slate-900 text-white'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50',
                  ].join(' ')}
                >
                  {d === 'All' ? 'All' : d.charAt(0) + d.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
            <div className="relative w-full sm:w-56">
              <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setVisibleCount(PAGE_SIZE)
                }}
                placeholder="Search problems or topics"
                className="w-full rounded-lg border border-slate-200 bg-white py-1.5 pl-8 pr-3 text-xs text-slate-700 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="py-10 text-center text-xs text-slate-400">Loading questions…</div>
          ) : filtered.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-400">No questions match this filter.</div>
          ) : (
            <>
              <div className="overflow-hidden rounded-lg border border-slate-100">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
                      <th className="w-10 px-3 py-2"></th>
                      <th className="px-3 py-2">Problem</th>
                      <th className="w-28 px-3 py-2">Difficulty</th>
                      <th className="hidden w-40 px-3 py-2 md:table-cell">Topics</th>
                      <th className="w-14 px-3 py-2 text-center">Link</th>
                      <th className="w-10 px-3 py-2 text-center">★</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filtered.slice(0, visibleCount).map((q) => {
                      const solved = solvedSet.has(q._id)
                      const marked = revisionSet.has(q._id)
                      return (
                        <tr key={q._id} className={solved ? 'bg-teal-50/30' : 'hover:bg-slate-50/70'}>
                          <td className="px-3 py-2.5">
                            <button
                              type="button"
                              onClick={() => onToggleSolved(q._id)}
                              aria-label={solved ? 'Mark as unsolved' : 'Mark as solved'}
                            >
                              {solved ? (
                                <CheckCircle2 size={18} className="text-teal-500" />
                              ) : (
                                <Circle size={18} className="text-slate-300 hover:text-slate-400" />
                              )}
                            </button>
                          </td>
                          <td className="px-3 py-2.5">
                            <p className={`font-medium ${solved ? 'text-slate-500 line-through' : 'text-slate-800'}`}>
                              {q.title}
                            </p>
                          </td>
                          <td className="px-3 py-2.5">
                            <span
                              className={`inline-flex rounded-md border px-2 py-0.5 text-[11px] font-semibold ${DIFFICULTY_STYLES[q.difficulty]}`}
                            >
                              {q.difficulty.charAt(0) + q.difficulty.slice(1).toLowerCase()}
                            </span>
                          </td>
                          <td className="hidden px-3 py-2.5 md:table-cell">
                            <div className="flex flex-wrap gap-1">
                              {q.topics.slice(0, 2).map((t) => (
                                <span
                                  key={t}
                                  className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600"
                                >
                                  {t}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="px-3 py-2.5 text-center">
                            <a
                              href={q.link}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center justify-center text-indigo-600 hover:text-indigo-500"
                              aria-label="Open on LeetCode"
                            >
                              <ExternalLink size={15} />
                            </a>
                          </td>
                          <td className="px-3 py-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => onToggleRevision(q._id)}
                              aria-label={marked ? 'Unmark for revision' : 'Mark for revision'}
                            >
                              <Star
                                size={16}
                                className={marked ? 'fill-amber-400 text-amber-400' : 'text-slate-300 hover:text-slate-400'}
                              />
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              {visibleCount < filtered.length && (
                <div className="mt-4 text-center">
                  <button
                    type="button"
                    onClick={() => setVisibleCount((v) => v + PAGE_SIZE)}
                    className="rounded-lg border border-slate-200 px-4 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
                  >
                    Show {Math.min(PAGE_SIZE, filtered.length - visibleCount)} more
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}

export default function CompanyDsaSheet() {
  const [companies, setCompanies] = useState([])
  const [openCompany, setOpenCompany] = useState(null)
  const [questionsByCompany, setQuestionsByCompany] = useState({})
  const [loadingCompany, setLoadingCompany] = useState(null)
  const [solvedSet, setSolvedSet] = useState(new Set())
  const [revisionSet, setRevisionSet] = useState(new Set())
  const [isLive, setIsLive] = useState(false)
  const [isCheckingApi, setIsCheckingApi] = useState(true)

  useEffect(() => {
    let cancelled = false

    fetchDsaCompanies().then((res) => {
      if (cancelled) return
      setCompanies(res?.companies || [])
      setIsCheckingApi(false)
      setIsLive((res?.companies || []).length > 0)
    })

    fetchDsaProgress().then((res) => {
      if (cancelled) return
      setSolvedSet(new Set(res?.solvedQuestionIds || []))
      setRevisionSet(new Set(res?.revisionQuestionIds || []))
    })

    return () => {
      cancelled = true
    }
  }, [])

  async function handleToggleCompany(company) {
    const next = openCompany === company ? null : company
    setOpenCompany(next)

    if (next && !questionsByCompany[next]) {
      setLoadingCompany(next)
      const res = await fetchDsaQuestions({ company: next })
      setQuestionsByCompany((prev) => ({ ...prev, [next]: res?.questions || [] }))
      setLoadingCompany(null)
    }
  }

  async function handleToggleSolved(questionId) {
    setSolvedSet((prev) => {
      const next = new Set(prev)
      next.has(questionId) ? next.delete(questionId) : next.add(questionId)
      return next
    })
    await toggleDsaSolved(questionId)
  }

  async function handleToggleRevision(questionId) {
    setRevisionSet((prev) => {
      const next = new Set(prev)
      next.has(questionId) ? next.delete(questionId) : next.add(questionId)
      return next
    })
    await toggleDsaRevision(questionId)
  }

  const totalQuestions = companies.reduce((sum, c) => sum + c.total, 0)
  const totalSolved = Object.values(questionsByCompany)
    .flat()
    .filter((q) => solvedSet.has(q._id)).length

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-card">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-teal-500/15">
              <Code2 size={20} className="text-teal-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-semibold text-slate-900">Company-wise DSA Sheet</h1>
                {!isCheckingApi && (
                  <span
                    className={[
                      'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold',
                      isLive ? 'bg-teal-50 text-teal-700' : 'bg-slate-100 text-slate-500',
                    ].join(' ')}
                    title={isLive ? 'Data loaded from the live backend API' : 'Backend unreachable — using local progress'}
                  >
                    {isLive ? <Wifi size={11} /> : <WifiOff size={11} />}
                    {isLive ? 'Live API' : 'Local mode'}
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm text-slate-500">
                Curated LeetCode problems grouped by the companies that ask them, ranked by interview frequency.
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-semibold text-slate-900">
              {totalSolved}
              <span className="text-sm font-normal text-slate-400"> / {totalQuestions || '—'}</span>
            </p>
            <p className="text-xs text-slate-500">solved across expanded companies</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {companies.length === 0 && !isCheckingApi && (
          <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-400 shadow-card">
            No company DSA data available yet.
          </div>
        )}
        {companies.map((companyStat) => (
          <CompanySection
            key={companyStat.company}
            companyStat={companyStat}
            isOpen={openCompany === companyStat.company}
            onToggle={() => handleToggleCompany(companyStat.company)}
            questions={questionsByCompany[companyStat.company] || []}
            isLoading={loadingCompany === companyStat.company}
            solvedSet={solvedSet}
            revisionSet={revisionSet}
            onToggleSolved={handleToggleSolved}
            onToggleRevision={handleToggleRevision}
          />
        ))}
      </div>
    </div>
  )
}
