import DsaQuestion from '../models/DsaQuestion.js'
import DsaProgress from '../models/DsaProgress.js'

/**
 * GET /api/dsa/companies
 * Returns every company with a question count + difficulty breakdown, so
 * the sheet's company selector can render counts without a second round trip.
 */
export async function getCompanies(req, res, next) {
  try {
    const rows = await DsaQuestion.aggregate([
      {
        $group: {
          _id: '$company',
          total: { $sum: 1 },
          easy: { $sum: { $cond: [{ $eq: ['$difficulty', 'EASY'] }, 1, 0] } },
          medium: { $sum: { $cond: [{ $eq: ['$difficulty', 'MEDIUM'] }, 1, 0] } },
          hard: { $sum: { $cond: [{ $eq: ['$difficulty', 'HARD'] }, 1, 0] } },
        },
      },
      { $sort: { total: -1 } },
    ])

    const companies = rows.map((r) => ({
      company: r._id,
      total: r.total,
      easy: r.easy,
      medium: r.medium,
      hard: r.hard,
    }))

    res.json({ companies })
  } catch (err) {
    next(err)
  }
}

/**
 * GET /api/dsa/questions?company=Google&difficulty=EASY&search=array
 */
export async function getQuestions(req, res, next) {
  try {
    const { company, difficulty, search } = req.query
    const filter = {}

    if (company) filter.company = company
    if (difficulty && difficulty !== 'All') filter.difficulty = difficulty
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { topics: { $in: [new RegExp(search, 'i')] } },
      ]
    }

    const questions = await DsaQuestion.find(filter)
      .sort({ frequency: -1 })
      .lean()

    res.json({ questions })
  } catch (err) {
    next(err)
  }
}

/**
 * GET /api/dsa/progress
 * Returns the authenticated user's solved + revision question IDs as plain
 * string arrays, ready to be turned into a Set on the frontend.
 */
export async function getProgress(req, res, next) {
  try {
    const progress = await DsaProgress.findOne({ userId: req.user._id }).lean()

    res.json({
      solvedQuestionIds: (progress?.solvedQuestionIds || []).map((id) => id.toString()),
      revisionQuestionIds: (progress?.revisionQuestionIds || []).map((id) => id.toString()),
    })
  } catch (err) {
    next(err)
  }
}

/**
 * POST /api/dsa/progress/toggle-solved   { questionId }
 */
export async function toggleSolved(req, res, next) {
  try {
    const { questionId } = req.body
    if (!questionId) {
      return res.status(400).json({ error: 'questionId is required' })
    }

    let progress = await DsaProgress.findOne({ userId: req.user._id })
    if (!progress) {
      progress = await DsaProgress.create({ userId: req.user._id, solvedQuestionIds: [], revisionQuestionIds: [] })
    }

    const idx = progress.solvedQuestionIds.findIndex((id) => id.toString() === questionId)
    let solved
    if (idx >= 0) {
      progress.solvedQuestionIds.splice(idx, 1)
      solved = false
    } else {
      progress.solvedQuestionIds.push(questionId)
      solved = true
    }
    await progress.save()

    res.json({ questionId, solved })
  } catch (err) {
    next(err)
  }
}

/**
 * POST /api/dsa/progress/toggle-revision   { questionId }
 */
export async function toggleRevision(req, res, next) {
  try {
    const { questionId } = req.body
    if (!questionId) {
      return res.status(400).json({ error: 'questionId is required' })
    }

    let progress = await DsaProgress.findOne({ userId: req.user._id })
    if (!progress) {
      progress = await DsaProgress.create({ userId: req.user._id, solvedQuestionIds: [], revisionQuestionIds: [] })
    }

    const idx = progress.revisionQuestionIds.findIndex((id) => id.toString() === questionId)
    let marked
    if (idx >= 0) {
      progress.revisionQuestionIds.splice(idx, 1)
      marked = false
    } else {
      progress.revisionQuestionIds.push(questionId)
      marked = true
    }
    await progress.save()

    res.json({ questionId, marked })
  } catch (err) {
    next(err)
  }
}
