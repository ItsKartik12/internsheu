import 'dotenv/config'
import dns from 'node:dns'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import mongoose from 'mongoose'

try {
  dns.setServers(['8.8.8.8', '1.1.1.1'])
} catch {
  // fallback to system resolver
}

import DsaQuestion from '../models/DsaQuestion.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const CSV_DIR = path.join(__dirname, '../data/dsa-csv')

// Minimal RFC-4180 CSV line parser. Needed because the "Topics" column
// contains comma-separated values wrapped in quotes (e.g. "Array, Hash
// Table"), which a naive `line.split(',')` would shred.
function parseCsv(text) {
  const rows = []
  let row = []
  let field = ''
  let inQuotes = false

  for (let i = 0; i < text.length; i++) {
    const char = text[i]
    const next = text[i + 1]

    if (inQuotes) {
      if (char === '"' && next === '"') {
        field += '"'
        i++
      } else if (char === '"') {
        inQuotes = false
      } else {
        field += char
      }
    } else if (char === '"') {
      inQuotes = true
    } else if (char === ',') {
      row.push(field)
      field = ''
    } else if (char === '\n' || char === '\r') {
      if (char === '\r' && next === '\n') i++
      row.push(field)
      rows.push(row)
      row = []
      field = ''
    } else {
      field += char
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field)
    rows.push(row)
  }
  return rows.filter((r) => r.length > 1 || (r.length === 1 && r[0] !== ''))
}

function slugify(title) {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

async function seedDsa() {
  const uri = process.env.MONGODB_URI
  if (!uri) {
    console.error('MONGODB_URI environment variable is required to run seedDsa script.')
    process.exit(1)
  }

  console.log('Connecting to MongoDB...')
  await mongoose.connect(uri)
  console.log('Connected successfully.')

  const files = fs.readdirSync(CSV_DIR).filter((f) => f.endsWith('.csv'))
  console.log(`Found ${files.length} company CSV files: ${files.join(', ')}`)

  let totalUpserted = 0

  for (const file of files) {
    const company = path.basename(file, '.csv')
    const raw = fs.readFileSync(path.join(CSV_DIR, file), 'utf-8')
    const rows = parseCsv(raw)
    const [header, ...dataRows] = rows

    const colIdx = {
      difficulty: header.indexOf('Difficulty'),
      title: header.indexOf('Title'),
      frequency: header.indexOf('Frequency'),
      acceptance: header.indexOf('Acceptance Rate'),
      link: header.indexOf('Link'),
      topics: header.indexOf('Topics'),
    }

    let companyCount = 0
    for (const cols of dataRows) {
      const title = cols[colIdx.title]?.trim()
      const difficulty = cols[colIdx.difficulty]?.trim().toUpperCase()
      if (!title || !difficulty) continue

      const doc = {
        company,
        title,
        slug: slugify(title),
        difficulty,
        frequency: Number(cols[colIdx.frequency]) || 0,
        acceptanceRate: Number(cols[colIdx.acceptance]) || 0,
        link: cols[colIdx.link]?.trim() || '',
        topics: (cols[colIdx.topics] || '')
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean),
      }

      await DsaQuestion.findOneAndUpdate(
        { company: doc.company, slug: doc.slug },
        doc,
        { upsert: true, new: true }
      )
      companyCount++
    }

    console.log(`✓ ${company}: seeded ${companyCount} questions`)
    totalUpserted += companyCount
  }

  console.log('\n=============================================')
  console.log(`DSA seed completed. ${totalUpserted} questions upserted across ${files.length} companies.`)
  console.log('Collection: dsaquestions')
  console.log('=============================================\n')

  await mongoose.disconnect()
}

seedDsa().catch((err) => {
  console.error('DSA seed failed:', err)
  process.exit(1)
})
