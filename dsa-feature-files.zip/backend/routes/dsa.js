import { Router } from 'express'
import {
  getCompanies,
  getQuestions,
  getProgress,
  toggleSolved,
  toggleRevision,
} from '../controllers/dsaController.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

// All routes require authentication, consistent with the rest of the API.
router.use(authenticate)

router.get('/companies', getCompanies)
router.get('/questions', getQuestions)
router.get('/progress', getProgress)
router.post('/progress/toggle-solved', toggleSolved)
router.post('/progress/toggle-revision', toggleRevision)

export default router
