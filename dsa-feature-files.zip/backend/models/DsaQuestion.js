import mongoose from 'mongoose'

const { Schema } = mongoose

// One document per (company, problem) pair. The same LeetCode problem can
// legitimately appear under multiple companies (e.g. "Two Sum" is asked by
// almost everyone), so uniqueness is scoped to company + slug rather than
// slug alone.
const dsaQuestionSchema = new Schema(
  {
    company: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    difficulty: {
      type: String,
      enum: ['EASY', 'MEDIUM', 'HARD'],
      required: true,
      index: true,
    },
    frequency: {
      type: Number,
      default: 0,
    },
    acceptanceRate: {
      type: Number,
      default: 0,
    },
    link: {
      type: String,
      required: true,
    },
    topics: [{ type: String, trim: true }],
  },
  { timestamps: true }
)

dsaQuestionSchema.index({ company: 1, slug: 1 }, { unique: true })

export default mongoose.model('DsaQuestion', dsaQuestionSchema, 'dsaquestions')
