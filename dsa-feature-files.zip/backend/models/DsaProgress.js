import mongoose from 'mongoose'

const { Schema } = mongoose

// One document per user. Solved/revision state is stored as arrays of
// DsaQuestion ObjectIds rather than a boolean flag on each question, since
// "solved" is a per-user fact, not a property of the problem itself.
const dsaProgressSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
      index: true,
    },
    solvedQuestionIds: [
      {
        type: Schema.Types.ObjectId,
        ref: 'DsaQuestion',
      },
    ],
    revisionQuestionIds: [
      {
        type: Schema.Types.ObjectId,
        ref: 'DsaQuestion',
      },
    ],
  },
  { timestamps: true }
)

export default mongoose.model('DsaProgress', dsaProgressSchema, 'dsaprogress')
